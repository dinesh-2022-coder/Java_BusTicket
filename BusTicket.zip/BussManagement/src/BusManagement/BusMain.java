/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package BusManagement;


public class BusMain {
    
    public static void main(String[] args) {
        MainScreen mr = new MainScreen();
        mr.setVisible(true);
    }
    
}
